<html>
    <head>
        <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
        <link href="<?php echo e(asset('css/bootstrap.min.css'), false); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="container">
        	<div class="row mt-5">
            	<?php echo $__env->yieldContent('content'); ?>
        	</div>
        </div>
    </body>
</html>

<?php /**PATH C:\xampp\htdocs\todo\laravel\resources\views/app.blade.php ENDPATH**/ ?>