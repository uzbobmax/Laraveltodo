

<?php $__env->startSection('title', 'todo'); ?>

<?php $__env->startSection('list-item'); ?>
<div class="list">
	<h1>List tasks</h1>

		<ul>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($el->name, false); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
</div>
<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('list_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\todo\laravel\resources\views/listdata.blade.php ENDPATH**/ ?>