
<?php $__env->startSection('content'); ?>
    <p><form action="/create" method="post">
    	<?php echo csrf_field(); ?>
		<input type="text" name="insert_data">
		<input type="submit" value="Add Task">
</form></p>
<div class="container">
	<div class="row">
		<?php echo $__env->yieldContent('list-item'); ?>
	</div>
	
</div>

<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\todo\laravel\resources\views/list_create.blade.php ENDPATH**/ ?>