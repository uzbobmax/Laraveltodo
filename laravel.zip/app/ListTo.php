<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListTo extends Model
{
    public $table = 'list';
}
